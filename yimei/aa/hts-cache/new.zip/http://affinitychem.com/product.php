<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta name="Generator" content="ECSHOP v2.7.3" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="Keywords" content="affinitychem" />
<meta name="Description" content="affinitychem" />
<title>PRODUCT</title>
<link rel="shortcut icon" href="favicon.ico" />
<link rel="icon" href="animated_favicon.gif" type="image/gif" />
<link href="themes/affinitychem/css/default.css" rel="stylesheet" type="text/css" />
<link href="themes/affinitychem/css/banner.css" rel="stylesheet" type="text/css">
<link rel="alternate" type="application/rss+xml" title="RSS|product_affinitychem" href="feed.php" />
<script type="text/javascript" src="js/jquery-1.10.2.min.js"></script></head>
<body class="body2">
<div class="layout">
<div class="logo"><a href="index.php"><img src="themes/affinitychem/images/logo.png" border="0" /></a></div>
<div class="search"><form id="searchForm" name="searchForm" method="get" action="search.php" onSubmit="return checkSearchForm()"><input class="srk"  name="keywords" type="text" id="keyword" placeholder="Name/CAS No./Catalog No."  /><input type="submit" class="sinput" value="go" name="imageField"   /></form>
</div>
<div class="hometoprt">
<div class="wcl">Welcome to the Affinity Research Chemicals, Inc website!</div>
<div class="topnav" style="float:right"><a href="/article.php?id=14">HELP</a>丨<a href="/article.php?id=10">Contact us</a></div>
<!--<div class="topnav"><a href="#">REGISTER</a>丨<a href="#">log in</a>丨<a href="#">MY ACCOUNT</a>丨<a href="/article.php?id=14">HELP</a><a style="margin-right:0px;" href="#"><img src="themes/affinitychem/images/gwc.png" /></a></div> -->
</div>
<div class="clear"></div>
<div class="nav">
	<script type="text/javascript">
// Executes the function when DOM will be loaded fully
$(document).ready(function () {	
	// hover property will help us set the events for mouse enter and mouse leave
	$('.navigation li').hover(
		// When mouse enters the .navigation element
		function () {
			//Fade in the navigation submenu
			$('ul', this).fadeIn(); 	// fadeIn will show the sub cat menu
		}, 
		// When mouse leaves the .navigation element
		function () {
			//Fade out the navigation submenu
			$('ul', this).fadeOut();	 // fadeOut will hide the sub cat menu		
		}
	);
});
	</script>
<ul class="navigation"><li><a href="/">Home</a></li>
<li><a>About us</a>
<ul>
  <li>
	<a href="article.php?id=32" title="Company Information">Company Information</a>
	</li>
  <li>
	<a href="article.php?id=31" title="Our Expertise">Our Expertise</a>
	</li>
  <li>
	<a href="article.php?id=30" title="IP Protections">IP Protections</a>
	</li>
  <li>
	<a href="article.php?id=29" title="Privacy Policy">Privacy Policy</a>
	</li>
 
<div class="clear"></div>
</ul>
</li>
<li><a>Services</a>
<ul>
  <li>
	<a href="article.php?id=26" title="Peptide Modification">Peptide Modification</a>
	</li>
  <li>
	<a href="article.php?id=19" title="Contract Research">Contract Research</a>
	</li>
  <li>
	<a href="article.php?id=18" title="Custom Synthesis">Custom Synthesis</a>
	</li>
<div class="clear"></div>
</ul>
</li>
<li><a href="/article_cat.php?id=6">News</a></li>
<li><a href="/article.php?id=10">Contact us</a></li><li><a href="/product.php">Products</a></li>
</ul>
</div>
</div>
<div class="layout">
<div class="route">Your Position: <a href=".">Home</a> <code>></code> <a href="product.php">product</a>
<span style=" float:right; margin-right:200px;">Fused Heterocycles<b><a style=" margin-left:5px;font-family:Arial, Helvetica, sans-serif; font-size:13px;" href="article.php?id=35">- More Info -</a></b></span></div>
<div class="ny">
<div class="Productslf">
<ul id="nav">
    
            <li>
      <a href="category.php?id=1" target="_blank" class="selected">Diversity Oriented Building Blocks</a>
     <ul>
          <li>
      <a href="category.php?id=10" target="_blank" class="selected">By Functional Groups</a>
     <ul>
        <li>
    <a href="category.php?id=11" target="_blank" class="selected2">Aldehydes/Ketones</a>
    <ul>
       </ul>
    </li>
      <li>
    <a href="category.php?id=102" target="_blank" class="selected2">Alcohols/Thiols/Phenols/Alkoxys</a>
    <ul>
       </ul>
    </li>
      <li>
    <a href="category.php?id=17" target="_blank" class="selected2">Amines/ Carbamates/ Nitros</a>
    <ul>
       </ul>
    </li>
      <li>
    <a href="category.php?id=13" target="_blank" class="selected2">Carboxamides/thioamides/Nitriles</a>
    <ul>
       </ul>
    </li>
      <li>
    <a href="category.php?id=14" target="_blank" class="selected2">Boronic Acids/Esters</a>
    <ul>
       </ul>
    </li>
      <li>
    <a href="category.php?id=18" target="_blank" class="selected2">Carboxylic Acids/Esters</a>
    <ul>
       </ul>
    </li>
      <li>
    <a href="category.php?id=104" target="_blank" class="selected2">Halides</a>
    <ul>
       </ul>
    </li>
      <li>
    <a href="category.php?id=16" target="_blank" class="selected2">Others</a>
    <ul>
       </ul>
    </li>
      </ul>
    </li>
              <li>
      <a href="category.php?id=2" target="_blank" class="selected">By Structure</a>
     <ul>
        <li>
    <a href="category.php?id=3" target="_blank" class="selected2">Hetero 6-membered Rings +</a>
    <ul>
   <li id="cattree3">
      <a href="category.php?id=19" target="_blank" onfocus="this.blur()">Pyrimidines</a> 
      <a href="category.php?id=20" target="_blank" onfocus="this.blur()">Pyridazines</a> 
      <a href="category.php?id=21" target="_blank" onfocus="this.blur()">Morpholines</a> 
      <a href="category.php?id=22" target="_blank" onfocus="this.blur()">Pyridines</a> 
      <a href="category.php?id=23" target="_blank" onfocus="this.blur()">Piperidines</a> 
      <a href="category.php?id=24" target="_blank" onfocus="this.blur()">Other 6-membered Rings</a> 
      <a href="category.php?id=25" target="_blank" onfocus="this.blur()">Pyrazines</a> 
      <a href="category.php?id=26" target="_blank" onfocus="this.blur()">Piperazines</a> 
      <a href="category.php?id=40" target="_blank" onfocus="this.blur()">Pyrans</a> 
      <a href="category.php?id=41" target="_blank" onfocus="this.blur()">Tetrahydropyrans</a> 
        </li>
       </ul>
    </li>
      <li>
    <a href="category.php?id=27" target="_blank" class="selected2">Hetero 5-membered Rings +</a>
    <ul>
   <li id="cattree27">
      <a href="category.php?id=28" target="_blank" onfocus="this.blur()">Oxazoles</a> 
      <a href="category.php?id=29" target="_blank" onfocus="this.blur()">Pyrazoles</a> 
      <a href="category.php?id=30" target="_blank" onfocus="this.blur()">Imidazoles</a> 
      <a href="category.php?id=31" target="_blank" onfocus="this.blur()">Thiophenes</a> 
      <a href="category.php?id=32" target="_blank" onfocus="this.blur()">Triazoles</a> 
      <a href="category.php?id=33" target="_blank" onfocus="this.blur()">Tetrazoles</a> 
      <a href="category.php?id=34" target="_blank" onfocus="this.blur()">Pyrrolidines</a> 
      <a href="category.php?id=35" target="_blank" onfocus="this.blur()">Pyrroles</a> 
      <a href="category.php?id=36" target="_blank" onfocus="this.blur()">Thiazoles</a> 
      <a href="category.php?id=37" target="_blank" onfocus="this.blur()">Isothiazoles</a> 
      <a href="category.php?id=38" target="_blank" onfocus="this.blur()">Furans</a> 
      <a href="category.php?id=39" target="_blank" onfocus="this.blur()">Tetrahydrofurans</a> 
      <a href="category.php?id=42" target="_blank" onfocus="this.blur()">Other 5-membered Rings</a> 
        </li>
       </ul>
    </li>
      <li>
    <a href="category.php?id=43" target="_blank" class="selected2">Other Hetero Rings +</a>
    <ul>
   <li id="cattree43">
      <a href="category.php?id=44" target="_blank" onfocus="this.blur()">Aziridines</a> 
      <a href="category.php?id=45" target="_blank" onfocus="this.blur()">Azetidines</a> 
      <a href="category.php?id=46" target="_blank" onfocus="this.blur()">Epoxides</a> 
      <a href="category.php?id=47" target="_blank" onfocus="this.blur()">Oxetanes</a> 
      <a href="category.php?id=48" target="_blank" onfocus="this.blur()">&gt;6-membered Rings</a> 
        </li>
       </ul>
    </li>
      <li>
    <a href="category.php?id=49" target="_blank" class="selected2">Highly Substituted Benzenes +</a>
    <ul>
   <li id="cattree49">
      <a href="category.php?id=50" target="_blank" onfocus="this.blur()">Tri-substituted</a> 
      <a href="category.php?id=51" target="_blank" onfocus="this.blur()">Tetra-substituted</a> 
      <a href="category.php?id=52" target="_blank" onfocus="this.blur()">Other-substituted</a> 
      <a href="category.php?id=53" target="_blank" onfocus="this.blur()">Naphthalenes</a> 
        </li>
       </ul>
    </li>
      <li>
    <a href="category.php?id=54" target="_blank" class="selected2">Fused Heterocycles +</a>
    <ul>
   <li id="cattree54">
      <a href="category.php?id=168" target="_blank" onfocus="this.blur()">Pyrrolo[3,4-d]pyrimidines</a> 
      <a href="category.php?id=105" target="_blank" onfocus="this.blur()">Pyrrolo[2,3-b]pyridines</a> 
      <a href="category.php?id=106" target="_blank" onfocus="this.blur()">Pyrrolo[2,3-c]pyridines</a> 
      <a href="category.php?id=107" target="_blank" onfocus="this.blur()">Pyrrolo[3,2-b]pyridines</a> 
      <a href="category.php?id=109" target="_blank" onfocus="this.blur()">Pyrrolo[3,2-c]pyridines</a> 
      <a href="category.php?id=110" target="_blank" onfocus="this.blur()">Pyrrolo[3,2-d]pyrimidines</a> 
      <a href="category.php?id=112" target="_blank" onfocus="this.blur()">Pyrrolo[2,3-d]pyrimidines</a> 
      <a href="category.php?id=113" target="_blank" onfocus="this.blur()">Pyrrolo[1,2-c]pyrimidines</a> 
      <a href="category.php?id=114" target="_blank" onfocus="this.blur()">Pyrrolo[1,2-a]pyrimidines</a> 
      <a href="category.php?id=115" target="_blank" onfocus="this.blur()">Pyrrolo[2,3-b]pyrazines</a> 
      <a href="category.php?id=116" target="_blank" onfocus="this.blur()">Pyrrolo[3,4-b]pyrazines</a> 
      <a href="category.php?id=117" target="_blank" onfocus="this.blur()">Pyrrolo[1,2-a]pyrazines</a> 
      <a href="category.php?id=118" target="_blank" onfocus="this.blur()">Pyrrolo[2,1-f][1,2,4]triazines</a> 
      <a href="category.php?id=120" target="_blank" onfocus="this.blur()">Other Pyrrolos</a> 
      <a href="category.php?id=121" target="_blank" onfocus="this.blur()">Pyrazolo[3,4-b]pyrazines</a> 
      <a href="category.php?id=122" target="_blank" onfocus="this.blur()">Pyrazolo[4,3-b]pyrazines</a> 
      <a href="category.php?id=123" target="_blank" onfocus="this.blur()">Pyrazolo[1,5-a][1,3,5]triazines</a> 
      <a href="category.php?id=124" target="_blank" onfocus="this.blur()">Pyrazolo[1,5-a]pyrimidines</a> 
      <a href="category.php?id=125" target="_blank" onfocus="this.blur()">Pyrazolo[3,4-d]pyrimidines</a> 
      <a href="category.php?id=126" target="_blank" onfocus="this.blur()">Pyrazolo[1,5-c]pyrimidines</a> 
      <a href="category.php?id=127" target="_blank" onfocus="this.blur()">Pyrazolo[4,3-d]pyrimidines</a> 
      <a href="category.php?id=128" target="_blank" onfocus="this.blur()">Pyrazolo[4,3-b]pyridines</a> 
      <a href="category.php?id=129" target="_blank" onfocus="this.blur()">Pyrazolo[3,4-c]pyridines</a> 
      <a href="category.php?id=130" target="_blank" onfocus="this.blur()">Pyrazolo[1,5-a]pyridines</a> 
      <a href="category.php?id=131" target="_blank" onfocus="this.blur()">Pyrazolo[3,4-b]pyridines</a> 
      <a href="category.php?id=132" target="_blank" onfocus="this.blur()">Pyrazolo[4,3-c]pyridines</a> 
      <a href="category.php?id=133" target="_blank" onfocus="this.blur()">Other Pyrazolos</a> 
      <a href="category.php?id=134" target="_blank" onfocus="this.blur()">Imidazo[4,5-b]pyridines</a> 
      <a href="category.php?id=135" target="_blank" onfocus="this.blur()">Imidazo[1,2-a]pyridines</a> 
      <a href="category.php?id=136" target="_blank" onfocus="this.blur()">Imidazo[1,5-a]pyridines</a> 
      <a href="category.php?id=137" target="_blank" onfocus="this.blur()">Imidazo[4,5-c]pyridines</a> 
      <a href="category.php?id=138" target="_blank" onfocus="this.blur()">Imidazo[1,2-a]pyrimidines</a> 
      <a href="category.php?id=139" target="_blank" onfocus="this.blur()">Imidazo[1,2-a]pyrazines</a> 
      <a href="category.php?id=140" target="_blank" onfocus="this.blur()">Imidazo[1,2-b]pyridazines</a> 
      <a href="category.php?id=141" target="_blank" onfocus="this.blur()">Other imidazos</a> 
      <a href="category.php?id=142" target="_blank" onfocus="this.blur()">Thiazolo[4,5-c]pyridines</a> 
      <a href="category.php?id=143" target="_blank" onfocus="this.blur()">Thiazolo[5,4-b]pyridines</a> 
      <a href="category.php?id=144" target="_blank" onfocus="this.blur()">Thiazolo[5,4-c]pyridines</a> 
      <a href="category.php?id=145" target="_blank" onfocus="this.blur()">Thiazolo[5,4-d]pyrimidines</a> 
      <a href="category.php?id=146" target="_blank" onfocus="this.blur()">Pyrido[2,3-b]pyrazines</a> 
      <a href="category.php?id=148" target="_blank" onfocus="this.blur()">Pyrido[3,2-d]pyrimidines</a> 
      <a href="category.php?id=149" target="_blank" onfocus="this.blur()">Quinolines</a> 
      <a href="category.php?id=150" target="_blank" onfocus="this.blur()">Isoquinolines</a> 
      <a href="category.php?id=151" target="_blank" onfocus="this.blur()">Pyrido[2,3-d]pyrimidines</a> 
      <a href="category.php?id=152" target="_blank" onfocus="this.blur()">Quinazolines</a> 
      <a href="category.php?id=153" target="_blank" onfocus="this.blur()">Benzothiazoles</a> 
      <a href="category.php?id=154" target="_blank" onfocus="this.blur()">Benzoisothiazoles</a> 
      <a href="category.php?id=155" target="_blank" onfocus="this.blur()">Benzothiophenes</a> 
      <a href="category.php?id=156" target="_blank" onfocus="this.blur()">Benzopyrans</a> 
      <a href="category.php?id=157" target="_blank" onfocus="this.blur()">Benzofurans</a> 
      <a href="category.php?id=158" target="_blank" onfocus="this.blur()">Benzoimidazoles</a> 
      <a href="category.php?id=159" target="_blank" onfocus="this.blur()">Indoles</a> 
      <a href="category.php?id=160" target="_blank" onfocus="this.blur()">Indazoles</a> 
      <a href="category.php?id=161" target="_blank" onfocus="this.blur()">Indolines</a> 
      <a href="category.php?id=162" target="_blank" onfocus="this.blur()">Isoindolines</a> 
      <a href="category.php?id=163" target="_blank" onfocus="this.blur()">Indolizines</a> 
      <a href="category.php?id=164" target="_blank" onfocus="this.blur()">Thienopyrimidines</a> 
      <a href="category.php?id=119" target="_blank" onfocus="this.blur()">Thienopyridine</a> 
      <a href="category.php?id=165" target="_blank" onfocus="this.blur()">Naphthyridines</a> 
      <a href="category.php?id=166" target="_blank" onfocus="this.blur()">Others</a> 
        </li>
       </ul>
    </li>
      <li>
    <a href="category.php?id=57" target="_blank" class="selected2">Cycloalkanes +</a>
    <ul>
   <li id="cattree57">
      <a href="category.php?id=58" target="_blank" onfocus="this.blur()">Cyclopropanes</a> 
      <a href="category.php?id=59" target="_blank" onfocus="this.blur()">Cyclobutanes</a> 
      <a href="category.php?id=60" target="_blank" onfocus="this.blur()">Cyclopentanes</a> 
      <a href="category.php?id=61" target="_blank" onfocus="this.blur()">Cyclohexanes</a> 
      <a href="category.php?id=62" target="_blank" onfocus="this.blur()">Others</a> 
        </li>
       </ul>
    </li>
      <li>
    <a href="category.php?id=63" target="_blank" class="selected2">Spiro/Bridged Compounds</a>
    <ul>
       </ul>
    </li>
      </ul>
    </li>
             </ul>
  </li>
            <li>
      <a href="category.php?id=7" target="_blank" class="selected">Amino Acids and Peptides</a>
     <ul>
          <li>
      <a href="category.php?id=84" target="_blank" class="selected">N-methyl Amino Acids</a>
     <ul>
        </ul>
    </li>
              <li>
      <a href="category.php?id=85" target="_blank" class="selected">Linear Amino Acids</a>
     <ul>
        </ul>
    </li>
              <li>
      <a href="category.php?id=86" target="_blank" class="selected">Alicyclic Amino Acids</a>
     <ul>
        </ul>
    </li>
              <li>
      <a href="category.php?id=87" target="_blank" class="selected">Alanine Derivatives</a>
     <ul>
        </ul>
    </li>
              <li>
      <a href="category.php?id=88" target="_blank" class="selected">Homo-Amino Acids</a>
     <ul>
        </ul>
    </li>
              <li>
      <a href="category.php?id=89" target="_blank" class="selected">Arginine Derivatives</a>
     <ul>
        </ul>
    </li>
              <li>
      <a href="category.php?id=90" target="_blank" class="selected">Proline Derivatives</a>
     <ul>
        </ul>
    </li>
              <li>
      <a href="category.php?id=91" target="_blank" class="selected">Beta-Amino Acids</a>
     <ul>
        </ul>
    </li>
              <li>
      <a href="category.php?id=92" target="_blank" class="selected">Cysteine Derivatives</a>
     <ul>
        </ul>
    </li>
              <li>
      <a href="category.php?id=93" target="_blank" class="selected">Glycine Derivatives</a>
     <ul>
        </ul>
    </li>
              <li>
      <a href="category.php?id=94" target="_blank" class="selected">Isoleucine Derivatives</a>
     <ul>
        </ul>
    </li>
              <li>
      <a href="category.php?id=95" target="_blank" class="selected">Norleucine Derivatives</a>
     <ul>
        </ul>
    </li>
              <li>
      <a href="category.php?id=96" target="_blank" class="selected">Glutamic Acid Derivatives</a>
     <ul>
        </ul>
    </li>
              <li>
      <a href="category.php?id=97" target="_blank" class="selected">Leucine Derivatives</a>
     <ul>
        </ul>
    </li>
              <li>
      <a href="category.php?id=98" target="_blank" class="selected">Ornithine Derivatives</a>
     <ul>
        </ul>
    </li>
              <li>
      <a href="category.php?id=99" target="_blank" class="selected">Glutamine Derivatives</a>
     <ul>
        </ul>
    </li>
              <li>
      <a href="category.php?id=100" target="_blank" class="selected">Lysine Derivatives</a>
     <ul>
        </ul>
    </li>
              <li>
      <a href="category.php?id=101" target="_blank" class="selected">Others</a>
     <ul>
        </ul>
    </li>
             </ul>
  </li>
            <li>
      <a href="category.php?id=6" target="_blank" class="selected">Linkers and Other Biochemicals</a>
     <ul>
         </ul>
  </li>
            <li>
      <a href="category.php?id=8" target="_blank" class="selected">Ligands and Catalysts</a>
     <ul>
         </ul>
  </li>
            <li>
      <a href="category.php?id=5" target="_blank" class="selected">Reference  Compounds</a>
     <ul>
         </ul>
  </li>
            <li>
      <a href="category.php?id=9" target="_blank" class="selected">Optical-electronic  Sensitive Materials</a>
     <ul>
         </ul>
  </li>
         
</ul>
  
<div id="banner_tabs" class="flexslider">
  <ul class="slides">
      <li><a href="" style="background-image:url(data/afficheimg/1511233664192506045.jpg)"></a></li>
    </ul>
  <ul class="flex-direction-nav">
    <li><a class="flex-prev" href="javascript:;">Previous</a></li>
    <li><a class="flex-next" href="javascript:;">Next</a></li>
  </ul>
  <ol id="bannerCtrl" class="flex-control-nav flex-control-paging">
          <li>
     <a>1</a>
    </li> 
      </ol>
</div>
<div class="clear"></div>
<div class="bannerftbg"><img src="themes/affinitychem/images/banftbg.jpg" /></div>
<script>
function nTabs(thisObj,Num){
if(thisObj.className == "active")return;
var tabObj = thisObj.parentNode.id;
var tabList = document.getElementById(tabObj).getElementsByTagName("li");
for(i=0; i <tabList.length; i++)
{
  if (i == Num)
  {
   thisObj.className = "active"; 
      document.getElementById(tabObj+"_Content"+i).style.display = "block";
   }else{
   tabList[i].className = "normal"; 
   document.getElementById(tabObj+"_Content"+i).style.display = "none";
      }
   } 
}     
</script>
<div class="clear"></div>
   
<div class="newcp">
<ul>
          <li><p>2,7-dichloroimidazo[1,2-a]pyridine</p><div class="photo"><a href="goods.php?id=4044"><img src="images/201806/source_img/4044_G_1528157527156.jpg"/></a></div></li>
        <li><p>6-Bromo-2-cyclopropylpyrazolo[1,5-a]pyrimidine</p><div class="photo"><a href="goods.php?id=5236"><img src="images/201806/source_img/5236_G_1528157581554.jpg"/></a></div></li>
        <li><p>6-amino-4-chloronicotinonitrile</p><div class="photo"><a href="goods.php?id=993"><img src="images/201806/source_img/993_G_1528157231832.jpg"/></a></div></li>
        <li><p>3-(piperidin-4-yl)-1H-imidazo[4,5-c]pyridin-2(3H)-one</p><div class="photo"><a href="goods.php?id=4828"><img src="images/201806/source_img/4828_G_1528157561121.jpg"/></a></div></li>
        <li><p>1-(ethoxycarbonyl)-3,3-difluorocyclobutanecarboxylic acid</p><div class="photo"><a href="goods.php?id=620"><img src="images/201806/source_img/620_G_1528157216542.jpg"/></a></div></li>
  
  
  
  </ul>
</div>
</div>
<div class="rt2">
<div class="lf">
   <div class="homecontact">
<p>Phone : 1-302-525-4060
<br/><span style="margin-left:37px;">1-302-407-6891</span>
<span></span>
<a href="mailto:sales@affinitychem.com" target="_blank" style="color: #666666;">Email : sales@affinitychem.com</a>
<span></span>
Fax : 1-888-683-0988
</p>
</div>
   <div class="Psearch">
<form action="search.php" method="get" name="advancedSearchForm" id="advancedSearchForm">
<div class="ss1"><input name="keywords" type="text" id="keyword" placeholder="By Name"  /><input type="submit" class="lfssan" value="go" name="Submit"   /></div></form>
<form action="search.php" method="get" name="advancedSearchForm" id="advancedSearchForm">
<input type="hidden" value="2" name="goods_type"/>
<div class="ss1"><input name="attr[24]" type="text" placeholder="By CAS"  /><input type="submit" class="lfssan" value="go" name="Submit"   /></div></form>
<form action="search.php" method="get" name="advancedSearchForm" id="advancedSearchForm">
<input type="hidden" value="2" name="goods_type"/>
<div class="ss1"><input name="attr[22]" type="text" placeholder="By Catalog Number"  /><input type="submit" class="lfssan" value="go" name="Submit"   /></div></form>
</div>
   <script type="text/javascript" src="js/banScroll.js"></script><div class="homelfimg">
<div id="banS" class="banS">
<dl>
    <dd><a href="goods.php?id=4044" target="_blank"><img border="0" src="images/201806/source_img/4044_G_1528157527156.jpg" width="156" height="156" /></a></dd>
    <dd><a href="goods.php?id=5236" target="_blank"><img border="0" src="images/201806/source_img/5236_G_1528157581554.jpg" width="156" height="156" /></a></dd>
    <dd><a href="goods.php?id=993" target="_blank"><img border="0" src="images/201806/source_img/993_G_1528157231832.jpg" width="156" height="156" /></a></dd>
    <dd><a href="goods.php?id=4828" target="_blank"><img border="0" src="images/201806/source_img/4828_G_1528157561121.jpg" width="156" height="156" /></a></dd>
    <dd><a href="goods.php?id=620" target="_blank"><img border="0" src="images/201806/source_img/620_G_1528157216542.jpg" width="156" height="156" /></a></dd>
  </dl>
<script type="text/javascript">
jQuery().ready(function() {
$('#banS').banScroll({blockWidth:156,blockHeight:156,numBgActiveColor:'#2399a1'});
});
</script>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="clear"></div>
<div class="clear"></div>
<div class="footer">
<div class="layout" style="background-color: #c7eee8;height: 105px;">
<div class="ftnav"><a href="/article.php?id=31">Our Expertise</a><a href="/article.php?id=29">Privacy Policy</a><a href="/article.php?id=33">Terms and Conditions</a><a href="/article.php?id=34">Career</a><a href="/article.php?id=10">Contact us</a></div>
<div class="ftbq">© 2012 Affinity Research Chemicals, Inc. All Rights Reserved.</div>
</div>
</div>
<script src="js/slider.js"></script>
<script type="text/javascript">
$(function() {
	var bannerSlider = new Slider($('#banner_tabs'), {
		time: 5000,
		delay: 400,
		event: 'hover',
		auto: true,
		mode: 'fade',
		controller: $('#bannerCtrl'),
		activeControllerCls: 'active'
	});
	$('#banner_tabs .flex-prev').click(function() {
		bannerSlider.prev()
	});
	$('#banner_tabs .flex-next').click(function() {
		bannerSlider.next()
	});
})
</script>
</body>
</html>