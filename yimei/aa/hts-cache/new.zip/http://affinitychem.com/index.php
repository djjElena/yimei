<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta name="Generator" content="ECSHOP v2.7.3" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />


<title>dafa888</title>
<meta name="keywords" content="dafa888"/>
<meta name="description" content="dafa888,官方贵宾通道,优于普通会员的尊贵体验.专属客服,优惠更多,存取款速度更快.dafa888娱乐,首选品牌." />
<meta http-equiv="Cache-Control" content="no-transform"/>
<meta http-equiv="Cache-Control" content="no-siteapp"/>
<meta name="applicable-device" content="pc,mobile">
<meta name="MobileOptimized" content="width"/>
<meta name="HandheldFriendly" content="true"/>
<link rel="shortcut icon" href="favicon.ico" />
<link rel="icon" href="animated_favicon.gif" type="image/gif" />
<link href="themes/affinitychem/css/default.css" rel="stylesheet" type="text/css" />
<link href="themes/affinitychem/css/banner.css" rel="stylesheet" type="text/css">
<link rel="alternate" type="application/rss+xml" title="RSS|affinitychem" href="feed.php" />
<script type="text/javascript" src="js/jquery-1.10.2.min.js"></script></head>
<body class="homebody">
<h3>dafa888</h3>
<div class="layout">
<div class="logo"><a href="index.php"><img src="themes/affinitychem/images/logo.png" border="0" /></a></div>
<div class="search"><form id="searchForm" name="searchForm" method="get" action="search.php" onSubmit="return checkSearchForm()"><input class="srk"  name="keywords" type="text" id="keyword" placeholder="Name/CAS No./Catalog No."  /><input type="submit" class="sinput" value="go" name="imageField"   /></form>
</div>
<div class="hometoprt">
<div class="wcl">Welcome to the Affinity Research Chemicals, Inc website!</div>
<div class="topnav" style="float:right"><a href="/article.php?id=14">HELP</a>丨<a href="/article.php?id=10">Contact us</a></div>
<!--<div class="topnav"><a href="#">REGISTER</a>丨<a href="#">log in</a>丨<a href="#">MY ACCOUNT</a>丨<a href="/article.php?id=14">HELP</a><a style="margin-right:0px;" href="#"><img src="themes/affinitychem/images/gwc.png" /></a></div> -->
</div>
<div class="clear"></div>
<div class="nav">
	<script type="text/javascript">
// Executes the function when DOM will be loaded fully
$(document).ready(function () {	
	// hover property will help us set the events for mouse enter and mouse leave
	$('.navigation li').hover(
		// When mouse enters the .navigation element
		function () {
			//Fade in the navigation submenu
			$('ul', this).fadeIn(); 	// fadeIn will show the sub cat menu
		}, 
		// When mouse leaves the .navigation element
		function () {
			//Fade out the navigation submenu
			$('ul', this).fadeOut();	 // fadeOut will hide the sub cat menu		
		}
	);
});
	</script>
<ul class="navigation"><li><a href="/">Home</a></li>
<li><a>About us</a>
<ul>
  <li>
	<a href="article.php?id=32" title="Company Information">Company Information</a>
	</li>
  <li>
	<a href="article.php?id=31" title="Our Expertise">Our Expertise</a>
	</li>
  <li>
	<a href="article.php?id=30" title="IP Protections">IP Protections</a>
	</li>
  <li>
	<a href="article.php?id=29" title="Privacy Policy">Privacy Policy</a>
	</li>
 
<div class="clear"></div>
</ul>
</li>
<li><a>Services</a>
<ul>
  <li>
	<a href="article.php?id=26" title="Peptide Modification">Peptide Modification</a>
	</li>
  <li>
	<a href="article.php?id=19" title="Contract Research">Contract Research</a>
	</li>
  <li>
	<a href="article.php?id=18" title="Custom Synthesis">Custom Synthesis</a>
	</li>
<div class="clear"></div>
</ul>
</li>
<li><a href="/article_cat.php?id=6">News</a></li>
<li><a href="/article.php?id=10">Contact us</a></li><li><a href="/product.php">Products</a></li>
</ul>
</div>
</div>
<div class="layout">
  
  
<div id="banner_tabs" class="flexslider">
  <ul class="slides">
      <li><a href="http://" style="background-image:url(data/afficheimg/20171115odpgqe.jpg)"></a></li>
      <li><a href="http://" style="background-image:url(data/afficheimg/20171115snzskm.jpg)"></a></li>
    </ul>
  <ul class="flex-direction-nav">
    <li><a class="flex-prev" href="javascript:;">Previous</a></li>
    <li><a class="flex-next" href="javascript:;">Next</a></li>
  </ul>
  <ol id="bannerCtrl" class="flex-control-nav flex-control-paging">
          <li>
     <a>1</a>
    </li> 
         <li>
     <a>2</a>
    </li> 
      </ol>
</div>
<div class="clear"></div>
<div class="bannerftbg"><img src="themes/affinitychem/images/banftbg.jpg" /></div>
<script>
function nTabs(thisObj,Num){
if(thisObj.className == "active")return;
var tabObj = thisObj.parentNode.id;
var tabList = document.getElementById(tabObj).getElementsByTagName("li");
for(i=0; i <tabList.length; i++)
{
  if (i == Num)
  {
   thisObj.className = "active"; 
      document.getElementById(tabObj+"_Content"+i).style.display = "block";
   }else{
   tabList[i].className = "normal"; 
   document.getElementById(tabObj+"_Content"+i).style.display = "none";
      }
   } 
}     
</script>
<div class="clear"></div>
<script>
function nTabs(thisObj,Num){
if(thisObj.className == "active")return;
var tabObj = thisObj.parentNode.id;
var tabList = document.getElementById(tabObj).getElementsByTagName("li");
for(i=0; i <tabList.length; i++)
{
  if (i == Num)
  {
   thisObj.className = "active"; 
      document.getElementById(tabObj+"_Content"+i).style.display = "block";
   }else{
   tabList[i].className = "normal"; 
   document.getElementById(tabObj+"_Content"+i).style.display = "none";
      }
   } 
}     
</script>
<div class="clear"></div>
   
   <div class="middle">
   
<div class="lf">
   
   <div class="homecontact">
<p>Phone : 1-302-525-4060
<br/><span style="margin-left:37px;">1-302-407-6891</span>
<span></span>
<a href="mailto:sales@affinitychem.com" target="_blank" style="color: #666666;">Email : sales@affinitychem.com</a>
<span></span>
Fax : 1-888-683-0988
</p>
</div>
   <div class="Psearch">
<form action="search.php" method="get" name="advancedSearchForm" id="advancedSearchForm">
<div class="ss1"><input name="keywords" type="text" id="keyword" placeholder="By Name"  /><input type="submit" class="lfssan" value="go" name="Submit"   /></div></form>
<form action="search.php" method="get" name="advancedSearchForm" id="advancedSearchForm">
<input type="hidden" value="2" name="goods_type"/>
<div class="ss1"><input name="attr[24]" type="text" placeholder="By CAS"  /><input type="submit" class="lfssan" value="go" name="Submit"   /></div></form>
<form action="search.php" method="get" name="advancedSearchForm" id="advancedSearchForm">
<input type="hidden" value="2" name="goods_type"/>
<div class="ss1"><input name="attr[22]" type="text" placeholder="By Catalog Number"  /><input type="submit" class="lfssan" value="go" name="Submit"   /></div></form>
</div>
   <script type="text/javascript" src="js/banScroll.js"></script><div class="homelfimg">
<div id="banS" class="banS">
<dl>
    <dd><a href="goods.php?id=10035" target="_blank"><img border="0" src="images/201806/source_img/10035_G_1528158547440.jpg" width="156" height="156" /></a></dd>
    <dd><a href="goods.php?id=10070" target="_blank"><img border="0" src="images/201806/source_img/10070_G_1528158549905.jpg" width="156" height="156" /></a></dd>
    <dd><a href="goods.php?id=10108" target="_blank"><img border="0" src="images/201806/source_img/10108_G_1528158550184.jpg" width="156" height="156" /></a></dd>
  </dl>
<script type="text/javascript">
jQuery().ready(function() {
$('#banS').banScroll({blockWidth:156,blockHeight:156,numBgActiveColor:'#2399a1'});
});
</script>
</div>
</div></div>
   
   
   
   <div class="hometab">
<ul id="myTab1" class="tabnav"> 
      <li class=active onmouseover="nTabs(this,0);"><img src="themes/affinitychem/images/tab1.png" /></li>
      <li class=normal onmouseover="nTabs(this,1);"><img src="themes/affinitychem/images/tab2.png" /></li>	
	  <li class=normal onmouseover="nTabs(this,2);"><img src="themes/affinitychem/images/tab3.png" /></li>	
	  <li class=normal onmouseover="nTabs(this,3);"><img src="themes/affinitychem/images/tab4.png" /></li>	
	  <li class=normal onmouseover="nTabs(this,4);"><img src="themes/affinitychem/images/tab5.png" /></li>	
	  <li class=normal onmouseover="nTabs(this,5);"><img src="themes/affinitychem/images/tab6.png" /></li>		
    </ul>  
	<div class="clear"></div> 
    <div id="myTab1_Content0" class="tabbox1">
		<p>At affinity, we are positioned to meet the evolving needs of medicinal chemists for exploring structural diversity and novel IP spaces. We focus on building blocks that are Structurally Intriguing, Metabolically Stable, and Convenient to Diversity.</p>
<p>&nbsp;</p>
<p>Our chemists are willing to take the synthetic challenges to make unique and hard to find building blocks. We are proud to be the first to make several classes of compounds commercially available for research community. New building blocks are synthesized in our Delaware lab and added to our catalog every month.</p> 
<p>&nbsp;</p>
<p>We are capable of scaling up most of the building blocks we have. About 5% of our building blocks have been scaled up to multi-kilos or larger quantities. <a href="#">Click here for examples of building blocks we scaled up recently.</a></p> 
<p>&nbsp;</p>
<p>If there are building blocks that you are interested, but nowhere to find, please send us an email to <a href="mailto:info@affinitychem.com" target="_blank">info@affinitychem.com,</a> with the structures. We will keep all your compound information confidential.</p>
<p>&nbsp;</p>
<p><a href="category.php?id=1">Pleas click here for detailed building block product list.</a></p>
	</div>
    <div id="myTab1_Content1" class="tabbox2" style="display:none">
	<p>Affinity offers you a full spectrum of precisely defined Polyethylene Glycol (P-PEG®) cross-linkers for all of your biological applications. Our P-PEG® linkers generally bear two orthogonal reactive groups that will covalently attach with certain functional groups such as amines and sulfhydryls. Our P-PEG® linkers are single molecular weight compounds with fixed length.  These products provide the diverse methods for peptide, protein, or other macromolecular conjugation and immobilization. <a href="category.php?id=6">Click here to view our line of products.</a></p>
<p>&nbsp;</p>
<p>By collaborating with Professor Joe Fox at University of Delaware, we are able to commercialize a new class of bioorthogonal labeling reagents, based on Tetrazine-Trans-cyclooctene (TCO) ligation. This uniquely rapid labeling technique has becoming a very powerful tool for in vivo labeling and imaging. Click here for details.</p>
</div>
	<div id="myTab1_Content2" class="tabbox3" style="display:none"><p>
	<p>We offer a variety of ligands and precious metal catalysts at very competitive price. Our products are manufactured according to vigorous industry standards. Each batch of products is assayed and fully characterized to assure quality. </p>
<p>&nbsp;</p>
<p>With our extensive knowledge and experience in catalysis technologies, we can provide our customers the services they need:</p>
<p>&nbsp;</p>
<p>•	Catalyst screening at Laboratory Scale </p>
<p>&nbsp;</p>
<p>•	Custom catalysts or precursors manufacturing</p>
<p>&nbsp;</p>
<p>•	Process optimization and scale up</p>
<p>&nbsp;</p>
<p>•	High temperature, high pressure hydrogenation and hydrogenolysis at various</p>
<p>&nbsp;</p>
<p>        scale  (from gram to metric ton)</p>
<p>&nbsp;</p>
<p>•	Recovery of values from spent catalyst residues</p>
</div>
	<div id="myTab1_Content3" class="tabbox4" style="display:none">
	<p>Unnatural amino acids (UAAs) are non-proteinogenic amino acids that either occur naturally or chemically synthesized. Their intrinsic structural diversity and functional versatility make them ideal as chiral building blocks and molecular scaffolds. They represent a powerful tool in drug discovery and lead optimization when incorporated into therapeutic peptidomimetics and peptide analogs. </p>
<p>We offer a broad range of UAAs (we are the sole supplier to over 100 products) to facilitate your research program. <a href="category.php?id=7">Click here for the list of UUAs we offered.</a></p>
<p>&nbsp;</p>
<p>At Affinity, we want to provide you the most unique peptide synthesis service. All our peptides are purified, lyophilized peptide with minimum purity of 95%. We specialize in the following synthesis service:</p>
<p>&nbsp;</p>
<p>•	Incorporation of Unnatural Amino Acids</p>
<p>&nbsp;</p>
<p>•	Stable Isotope Labeling</p>
<p>&nbsp;</p>
<p>•	PEGylation, Phosphorylation, Lipid Conjugation</p>
<p>&nbsp;</p>
<p>•	Cylcic Peptide Synthesis</p>
	</div>
	<div id="myTab1_Content4" class="tabbox5" style="display:none">
	<p>We have a team of Ph.D. chemists dedicated to standard and reference compounds synthesis. We mainly focus on the synthesis of compounds that are not commercially available through other vendors or new compounds.</p>
<p>&nbsp;</p>
<p>•	Synthesis of high purity reference standards (>99% pure or higher) used in 
         pharmacopoeia assays and tests.</p>
<p>&nbsp;</p>
<p>•	Synthesis of reference APIs for client’s biological effect comparison.</p>
<p>&nbsp;</p>
<p>•	Synthesis of metabolites based on proposed structures to facilitate structural 
         identification and profiling of metabolites by pharmaceutical companies.</p>
<p>&nbsp;</p>
<p>•	Synthesis stable isotope labeled (2H, 13C, 15N) APIs, impurities, metabolites or 
         other reference compounds.</p>
<p>&nbsp;</p>
<p>•	Synthesis of batch samples, and impurities to assist product registration by 
         agrochemical companies.</p>
</div>
	<div id="myTab1_Content5" class="tabbox6" style="display:none">
	<p>Our expertise in heterocyclic chemistry, organometallic chemistry, and cross-coupling reactions make us capable to synthesize optical-electronic sensitive materials.</p>
<p>&nbsp;</p>
<p>Our hole transport materials are based on triarylamines, with ultra-high purity. The HTMs have been used successfully in organic photoreceptor devices, solar cells, OLEDs and other organic electronics applications. In solar cells, HTMs can enable efficiencies in excess of 20%. Some recent research even showed that triacrylamines can play an important part in making highly stable perovskite solar cells by preventing metal atoms from the electrode from diffusing into the perovskite.</p>
<p>&nbsp;</p>
<p>Our charge generation materials include benzimidazole perylene (BZP), hydroxygallium phthalocyanine, titanyl phthalocyanine, These Charge Generation materials are for use in electrophotography, OLED, and organic solar cells.</p>
</div>
</div>   
<div class="rt">
   <div class="homenews">
<ul>
<li><a href="article.php?id=28">Affinity Research Chemicals has launched its new website...</a></li>
</ul>
<a href="/article_cat.php?id=6" target="_blank" class="more">more</a></div>
   
<script language="javascript">
function ale()
{
    alert("Subscribe to success！");
	window.location.reload(); 
}
</script>
<div class="Subscribe boxCenterList RelaArticle">
<div class="ss2"><input name="" class="inputBg" type="text" id="user_email"  placeholder="Email Address" /></div>
<div class="dyan"><input type="button" value="Subscribe email list" onclick="ale()"/>
<!--<div class="dyan"><input type="button" value="Subscribe email list" onclick="add_email_list();"/> -->
</div>
</div>
<script type="text/javascript">
var email = document.getElementById('user_email');
function add_email_list()
{
  if (check_email())
  {
    Ajax.call('user.php?act=email_list&job=add&email=' + email.value, '', rep_add_email_list, 'GET', 'TEXT');
  }
}
function rep_add_email_list(text)
{
  alert(text);
}
function cancel_email_list()
{
  if (check_email())
  {
    Ajax.call('user.php?act=email_list&job=del&email=' + email.value, '', rep_cancel_email_list, 'GET', 'TEXT');
  }
}
function rep_cancel_email_list(text)
{
  alert(text);
}
function check_email()
{
  if (Utils.isEmail(email.value))
  {
    return true;
  }
  else
  {
    alert('Email is invalid!');
    return false;
  }
}
</script>
   
<div class="homenews higs">
<ul>
<li><a href="article.php?id=36">Turbo-Grignard™ Isopropylmagnesium Chloride –Lithium Chlorid</a></li>
</ul>
<a href="/article_cat2.php?id=10" target="_blank" class="more">more</a></div>
</div>
   
<div class="clear"></div>
</div>
</div>
<div class="clear"></div>
<div class="footer">
<div class="layout" style="background-color: #c7eee8;height: 105px;">
<div class="ftnav"><a href="/article.php?id=31">Our Expertise</a><a href="/article.php?id=29">Privacy Policy</a><a href="/article.php?id=33">Terms and Conditions</a><a href="/article.php?id=34">Career</a><a href="/article.php?id=10">Contact us</a></div>
<div class="ftbq">© 2012 Affinity Research Chemicals, Inc. All Rights Reserved.</div>
</div>
</div>
<script src="js/slider.js"></script>
<script type="text/javascript">
$(function() {
	var bannerSlider = new Slider($('#banner_tabs'), {
		time: 5000,
		delay: 400,
		event: 'hover',
		auto: true,
		mode: 'fade',
		controller: $('#bannerCtrl'),
		activeControllerCls: 'active'
	});
	$('#banner_tabs .flex-prev').click(function() {
		bannerSlider.prev()
	});
	$('#banner_tabs .flex-next').click(function() {
		bannerSlider.next()
	});
})
</script>
</body>
</html>
